#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <stdlib.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "opencv2/imgproc/imgproc.hpp"
#include "kcftracker.hpp"

#include <dirent.h>

//Additional inclusion - Sushil Bharati
#include <ctime>
#include "opencv2/opencv.hpp"
#include "MBS.hpp"
#include <vector>
#include <cmath>
#include <cstring>
#include <stdlib.h>
#include <string>
using namespace std;
using namespace cv;

//Additional constant definition - Sushil Bharati
#define MAX_IMG_DIM 300
#define TOLERANCE 0.01
#define FRAME_MAX 20
#define SOBEL_THRESH 0.4


// ---- Functions added - Sushil Bharati ----

MBS::MBS(const Mat& src)
:mAttMapCount(0)
{
	mSrc=src.clone();
	mSaliencyMap = Mat::zeros(src.size(), CV_32FC1);

	split(mSrc, mFeatureMaps);

	for (int i = 0; i < mFeatureMaps.size(); i++)
	{
		//normalize(mFeatureMaps[i], mFeatureMaps[i], 255.0, 0.0, NORM_MINMAX);
		medianBlur(mFeatureMaps[i], mFeatureMaps[i], 5);
	}
}

void MBS::computeSaliency(bool use_geodesic)
{

        if (use_geodesic)
		mMBSMap = fastGeodesic(mFeatureMaps);
	else
		mMBSMap = fastMBS(mFeatureMaps);
	normalize(mMBSMap, mMBSMap, 0.0, 1.0, NORM_MINMAX);
	mSaliencyMap = mMBSMap;
}

Mat MBS::getSaliencyMap()
{
	Mat ret;
	normalize(mSaliencyMap, ret, 0.0, 255.0, NORM_MINMAX);
	ret.convertTo(ret, CV_8UC1);
	return ret;
}


void rasterScan(const Mat& featMap, Mat& map, Mat& lb, Mat& ub)
{
	Size sz = featMap.size();
	float *pMapup = (float*)map.data + 1;
	float *pMap = pMapup + sz.width;
	uchar *pFeatup = featMap.data + 1;
	uchar *pFeat = pFeatup + sz.width;
	uchar *pLBup = lb.data + 1;
	uchar *pLB = pLBup + sz.width;
	uchar *pUBup = ub.data + 1;
	uchar *pUB = pUBup + sz.width;

	float mapPrev;
	float featPrev;
	uchar lbPrev, ubPrev;

	float lfV, upV;
	int flag;
	for (int r = 1; r < sz.height - 1; r++)
	{
		mapPrev = *(pMap - 1);
		featPrev = *(pFeat - 1);
		lbPrev = *(pLB - 1);
		ubPrev = *(pUB - 1);


		for (int c = 1; c < sz.width - 1; c++)
		{
			lfV = MAX(*pFeat, ubPrev) - MIN(*pFeat, lbPrev);//(*pFeat >= lbPrev && *pFeat <= ubPrev) ? mapPrev : mapPrev + abs((float)(*pFeat) - featPrev);
			upV = MAX(*pFeat, *pUBup) - MIN(*pFeat, *pLBup);//(*pFeat >= *pLBup && *pFeat <= *pUBup) ? *pMapup : *pMapup + abs((float)(*pFeat) - (float)(*pFeatup));

			flag = 0;
			if (lfV < *pMap)
			{
				*pMap = lfV;
				flag = 1;
			}
			if (upV < *pMap)
			{
				*pMap = upV;
				flag = 2;
			}

			switch (flag)
			{
			case 0:		// no update
				break;
			case 1:		// update from left
				*pLB = MIN(*pFeat, lbPrev);
				*pUB = MAX(*pFeat, ubPrev);
				break;
			case 2:		// update from up
				*pLB = MIN(*pFeat, *pLBup);
				*pUB = MAX(*pFeat, *pUBup);
				break;
			default:
				break;
			}

			mapPrev = *pMap;
			pMap++; pMapup++;
			featPrev = *pFeat;
			pFeat++; pFeatup++;
			lbPrev = *pLB;
			pLB++; pLBup++;
			ubPrev = *pUB;
			pUB++; pUBup++;
		}
		pMapup += 2; pMap += 2;
		pFeat += 2; pFeatup += 2;
		pLBup += 2; pLB += 2;
		pUBup += 2; pUB += 2;
	}
}

void invRasterScan(const Mat& featMap, Mat& map, Mat& lb, Mat& ub)
{
	Size sz = featMap.size();
	int datalen = sz.width*sz.height;
	float *pMapdn = (float*)map.data + datalen - 2;
	float *pMap = pMapdn - sz.width;
	uchar *pFeatdn = featMap.data + datalen - 2;
	uchar *pFeat = pFeatdn - sz.width;
	uchar *pLBdn = lb.data + datalen - 2;
	uchar *pLB = pLBdn - sz.width;
	uchar *pUBdn = ub.data + datalen - 2;
	uchar *pUB = pUBdn - sz.width;
	
	float mapPrev;
	float featPrev;
	uchar lbPrev, ubPrev;

	float rtV, dnV;
	int flag;
	for (int r = 1; r < sz.height - 1; r++)
	{
		mapPrev = *(pMap + 1);
		featPrev = *(pFeat + 1);
		lbPrev = *(pLB + 1);
		ubPrev = *(pUB + 1);

		for (int c = 1; c < sz.width - 1; c++)
		{
			rtV = MAX(*pFeat, ubPrev) - MIN(*pFeat, lbPrev);//(*pFeat >= lbPrev && *pFeat <= ubPrev) ? mapPrev : mapPrev + abs((float)(*pFeat) - featPrev);
			dnV = MAX(*pFeat, *pUBdn) - MIN(*pFeat, *pLBdn);//(*pFeat >= *pLBdn && *pFeat <= *pUBdn) ? *pMapdn : *pMapdn + abs((float)(*pFeat) - (float)(*pFeatdn));

			flag = 0;
			if (rtV < *pMap)
			{
				*pMap = rtV;
				flag = 1;
			}
			if (dnV < *pMap)
			{
				*pMap = dnV;
				flag = 2;
			}

			switch (flag)
			{
			case 0:		// no update
				break;
			case 1:		// update from right
				*pLB = MIN(*pFeat, lbPrev);
				*pUB = MAX(*pFeat, ubPrev);
				break;
			case 2:		// update from down
				*pLB = MIN(*pFeat, *pLBdn);
				*pUB = MAX(*pFeat, *pUBdn);
				break;
			default:
				break;
			}

			mapPrev = *pMap;
			pMap--; pMapdn--;
			featPrev = *pFeat;
			pFeat--; pFeatdn--;
			lbPrev = *pLB;
			pLB--; pLBdn--;
			ubPrev = *pUB;
			pUB--; pUBdn--;
		}


		pMapdn -= 2; pMap -= 2;
		pFeatdn -= 2; pFeat -= 2;
		pLBdn -= 2; pLB -= 2;
		pUBdn -= 2; pUB -= 2;
	}
}

cv::Mat fastMBS(const std::vector<cv::Mat> featureMaps)
{
	assert(featureMaps[0].type() == CV_8UC1);

	Size sz = featureMaps[0].size();
	Mat ret = Mat::zeros(sz, CV_32FC1);
	if (sz.width < 3 || sz.height < 3)
		return ret;

	for (int i = 0; i < featureMaps.size(); i++)
	{
		Mat map = Mat::zeros(sz, CV_32FC1);
		Mat mapROI(map, Rect(1, 1, sz.width - 2, sz.height - 2));
		mapROI.setTo(Scalar(100000));
		Mat lb = featureMaps[i].clone();
		Mat ub = featureMaps[i].clone();

		rasterScan(featureMaps[i], map, lb, ub);
		invRasterScan(featureMaps[i], map, lb, ub);
		rasterScan(featureMaps[i], map, lb, ub);
		
		ret += map;
	}

	return ret;
	
}

float getThreshForGeo(const Mat& src)
{
	float ret;
	Size sz = src.size();

	uchar *pFeatup = src.data + 1;
	uchar *pFeat = pFeatup + sz.width;
	uchar *pfeatdn = pFeat + sz.width;

	float featPrev;

	for (int r = 1; r < sz.height - 1; r++)
	{
		featPrev = *(pFeat - 1);

		for (int c = 1; c < sz.width - 1; c++)
		{
			float temp = MIN(abs(*pFeat-featPrev),abs(*pFeat-*(pFeat+1)));
			temp = MIN(temp,abs(*pFeat-*pFeatup));
			temp = MIN(temp,abs(*pFeat-*pfeatdn));
			ret += temp;

			featPrev = *pFeat;
			pFeat++; pFeatup++; pfeatdn++;
		}
		pFeat += 2; pFeatup += 2; pfeatdn += 2;
	}
	return ret / ((sz.width - 2)*(sz.height - 2));
}

void rasterScanGeo(const Mat& featMap, Mat& map, float thresh)
{
	Size sz = featMap.size();
	float *pMapup = (float*)map.data + 1;
	float *pMap = pMapup + sz.width;
	uchar *pFeatup = featMap.data + 1;
	uchar *pFeat = pFeatup + sz.width;

	float mapPrev;
	float featPrev;

	float lfV, upV;
	int flag;
	for (int r = 1; r < sz.height - 1; r++)
	{
		mapPrev = *(pMap - 1);
		featPrev = *(pFeat - 1);


		for (int c = 1; c < sz.width - 1; c++)
		{
			lfV = (abs(featPrev - *pFeat)>thresh ? abs(featPrev - *pFeat):0.0f) + mapPrev;
			upV = (abs(*pFeatup - *pFeat)>thresh ? abs(*pFeatup - *pFeat):0.0f) + *pMapup;
			
			if (lfV < *pMap)
			{
				*pMap = lfV;
			}
			if (upV < *pMap)
			{
				*pMap = upV;
			}

			mapPrev = *pMap;
			pMap++; pMapup++;
			featPrev = *pFeat;
			pFeat++; pFeatup++;
		}
		pMapup += 2; pMap += 2;
		pFeat += 2; pFeatup += 2;
	}
}

void invRasterScanGeo(const Mat& featMap, Mat& map, float thresh)
{
	Size sz = featMap.size();
	int datalen = sz.width*sz.height;
	float *pMapdn = (float*)map.data + datalen - 2;
	float *pMap = pMapdn - sz.width;
	uchar *pFeatdn = featMap.data + datalen - 2;
	uchar *pFeat = pFeatdn - sz.width;

	float mapPrev;
	float featPrev;

	float rtV, dnV;
	int flag;
	for (int r = 1; r < sz.height - 1; r++)
	{
		mapPrev = *(pMap + 1);
		featPrev = *(pFeat + 1);

		for (int c = 1; c < sz.width - 1; c++)
		{
			rtV = (abs(featPrev - *pFeat)>thresh ? abs(featPrev - *pFeat):0.0f) + mapPrev;
			dnV = (abs(*pFeatdn - *pFeat)>thresh ? abs(*pFeatdn - *pFeat):0.0f) + *pMapdn;
			
			if (rtV < *pMap)
			{
				*pMap = rtV;
			}
			if (dnV < *pMap)
			{
				*pMap = dnV;
			}

			mapPrev = *pMap;
			pMap--; pMapdn--;
			featPrev = *pFeat;
			pFeat--; pFeatdn--;
		}


		pMapdn -= 2; pMap -= 2;
		pFeatdn -= 2; pFeat -= 2;
	}
}

cv::Mat fastGeodesic(const std::vector<cv::Mat> featureMaps)
{
	assert(featureMaps[0].type() == CV_8UC1);

	Size sz = featureMaps[0].size();
	Mat ret = Mat::zeros(sz, CV_32FC1);
	if (sz.width < 3 || sz.height < 3)
		return ret;


	for (int i = 0; i < featureMaps.size(); i++)
	{
		// determines the threshold for clipping
		float thresh = getThreshForGeo(featureMaps[i]);
		//cout << thresh << endl;
		Mat map = Mat::zeros(sz, CV_32FC1);
		Mat mapROI(map, Rect(1, 1, sz.width - 2, sz.height - 2));
		mapROI.setTo(Scalar(1000000000));

		rasterScanGeo(featureMaps[i], map, thresh);
		invRasterScanGeo(featureMaps[i], map, thresh);
		rasterScanGeo(featureMaps[i], map, thresh);

		ret += map;
	}

	return ret;

}

int findFrameMargin(const Mat& img, bool reverse)
{
	Mat edgeMap, edgeMapDil, edgeMask;
	Sobel(img, edgeMap, CV_16SC1, 0, 1);
	edgeMap = abs(edgeMap);
	edgeMap.convertTo(edgeMap, CV_8UC1);
	edgeMask = edgeMap < (SOBEL_THRESH * 255.0);
	dilate(edgeMap, edgeMapDil, Mat(), Point(-1, -1), 2);
	edgeMap = edgeMap == edgeMapDil;
	edgeMap.setTo(Scalar(0.0), edgeMask);


	if (!reverse)
	{
		for (int i = edgeMap.rows - 1; i >= 0; i--)
			if (mean(edgeMap.row(i))[0] > 0.6*255.0)
				return i + 1;
	}
	else
	{
		for (int i = 0; i < edgeMap.rows; i++)
			if (mean(edgeMap.row(i))[0] > 0.6*255.0)
				return edgeMap.rows - i;
	}

	return 0;
}

bool removeFrame(const cv::Mat& inImg, cv::Mat& outImg, cv::Rect &roi)
{
	if (inImg.rows < 2 * (FRAME_MAX + 3) || inImg.cols < 2 * (FRAME_MAX + 3))
	{
		roi = Rect(0, 0, inImg.cols, inImg.rows);
		outImg = inImg;
		return false;
	}

	Mat imgGray;
	cvtColor(inImg, imgGray, CV_RGB2GRAY);

	int up, dn, lf, rt;
	
	up = findFrameMargin(imgGray.rowRange(0, FRAME_MAX), false);
	dn = findFrameMargin(imgGray.rowRange(imgGray.rows - FRAME_MAX, imgGray.rows), true);
	lf = findFrameMargin(imgGray.colRange(0, FRAME_MAX).t(), false);
	rt = findFrameMargin(imgGray.colRange(imgGray.cols - FRAME_MAX, imgGray.cols).t(), true);

	int margin = MAX(up, MAX(dn, MAX(lf, rt)));
	if ( margin == 0 )
	{
		roi = Rect(0, 0, imgGray.cols, imgGray.rows);
		outImg = inImg;
		return false;
	}

	int count = 0;
	count = up == 0 ? count : count + 1;
	count = dn == 0 ? count : count + 1;
	count = lf == 0 ? count : count + 1;
	count = rt == 0 ? count : count + 1;

	// cut four border region if at least 2 border frames are detected
	if (count > 1)
	{
		margin += 2;
		roi = Rect(margin, margin, inImg.cols - 2*margin, inImg.rows - 2*margin);
		outImg = Mat(inImg, roi);

		return true;
	}

	// otherwise, cut only one border
	up = up == 0 ? up : up + 2;
	dn = dn == 0 ? dn : dn + 2;
	lf = lf == 0 ? lf : lf + 2;
	rt = rt == 0 ? rt : rt + 2;

	
	roi = Rect(lf, up, inImg.cols - lf - rt, inImg.rows - up - dn);
	outImg = Mat(inImg, roi);

	return true;
	
}

Mat doWork(
	const Mat& src,
	bool use_lab,
        bool remove_border,
	bool use_geodesic
	)
{
	Mat src_small;
	float w = (float)src.cols, h = (float)src.rows;
	float maxD = max(w,h);
	resize(src,src_small,Size((int)(MAX_IMG_DIM*w/maxD),(int)(MAX_IMG_DIM*h/maxD)),0.0,0.0,INTER_AREA);// standard: width: 300 pixel
	Mat srcRoi;
	Rect roi;
	// detect and remove the artifical frame of the image
        if (remove_border)
		removeFrame(src_small, srcRoi, roi);
	else 
	{
		srcRoi = src_small;
		roi = Rect(0, 0, src_small.cols, src_small.rows);
	}


	if (use_lab)        
		cvtColor(srcRoi, srcRoi, CV_RGB2Lab);
		
	/* Computing saliency */
	MBS mbs(srcRoi);
	mbs.computeSaliency(use_geodesic);
		
	Mat resultRoi=mbs.getSaliencyMap();
	Mat result = Mat::zeros(src_small.size(), CV_32FC1);

	normalize(resultRoi, Mat(result, roi), 0.0, 1.0, NORM_MINMAX);
		
	resize(result, result, src.size());
	return result;
}



// ----- Function addition ends here ----
//Main program commences as in ICTAI,2016

int main(int argc, char* argv[]){
   
	
	// datasets string array
   string seq[] ={"planestv_1","planestv_2"};
		
	// to loop all the datasets above
	float sum_time = 0.0; int limit , incr; 
	
	for (int dashcnt = 0; dashcnt < sizeof(seq)/sizeof(string); dashcnt++){ 
    	
//frame limits on each dataset based on their seq num

	if (dashcnt == 0) limit = 230; //for planestv_1
	if (dashcnt == 1) limit = 250; //for planestv_2



// ENABLE THIS TO GET TRE
  //incr = ceil(limit / 20); 
  //for (int cntr=1;cntr<=limit;cntr=cntr+incr){
	int cntr = 1;

string item = seq[dashcnt];

clock_t begin, end,t=0;


	if (argc > 5) return -1;

	bool HOG = true;	
	bool FIXEDWINDOW = true;
	bool MULTISCALE =false;
	bool SILENT = true; // to display frames on screen
	bool verbose = false; // to print average speed for each frame and in total - turn this false if SILENT = true or vice versa
	bool LAB = false;

	for(int i = 0; i < argc; i++){
		if ( strcmp (argv[i], "hog") == 0 )
			HOG = true;
		if ( strcmp (argv[i], "fixed_window") == 0 )
			FIXEDWINDOW = true;
		if ( strcmp (argv[i], "singlescale") == 0 )
			MULTISCALE = false;
		if ( strcmp (argv[i], "show") == 0 )
			SILENT = false;
		if ( strcmp (argv[i], "lab") == 0 ){
			LAB = true;
			HOG = true;
		}
		if ( strcmp (argv[i], "gray") == 0 )
			HOG = false;
	}
	
	
	// Create KCFTracker object
	KCFTracker tracker(HOG, FIXEDWINDOW, MULTISCALE, LAB);

	// Frame readed
	Mat frame;

	// Tracker results
	Rect result;

	// Path to list.txt
	ifstream listFile;
	string fileName = "images.txt";
  	listFile.open(fileName);

  	// Read groundtruth for the 1st frame -- modified -- this is eliminated for automation
  /* 	ifstream groundtruthFile;
	string groundtruth = "region.txt";
  	groundtruthFile.open(groundtruth);
  	string firstLine;
  	getline(groundtruthFile, firstLine);
	groundtruthFile.close();
  	
  	istringstream ss(firstLine);

  	// Read groundtruth like a dumb -- this approach does not work in our system
  	float x1, y1, x2, y2, x3, y3, x4, y4;
  	char ch;
	ss >> x1;
	ss >> ch;
	ss >> y1;
	ss >> ch;
	ss >> x2;
	ss >> ch;
	ss >> y2;
	ss >> ch;
	ss >> x3;
	ss >> ch;
	ss >> y3;
	ss >> ch;
	ss >> x4;
	ss >> ch;
	ss >> y4; 

	// Using min and max of X and Y for groundtruth rectangle
	float xMin =  min(x1, min(x2, min(x3, x4)));
	float yMin =  min(y1, min(y2, min(y3, y4)));
	float width = max(x1, max(x2, max(x3, x4))) - xMin;
	float height = max(y1, max(y2, max(y3, y4))) - yMin;
	

// Modified by Sushil - Read Ground truth like a 'pro'

char ch;
ss >> xMin >> ch >> yMin >> ch >> xMax >> ch >> yMax; 
	width = xMax - xMin; height = yMax - yMin;
*/	
float xMin,yMin,xMax,yMax,width,height;

  string folder_add = "./datasets/" + item;
  string frameName;
	// Read Images
	ifstream listFramesFile;
	string listFrames = folder_add + "/images.txt";
	listFramesFile.open(listFrames);
	
	// for (int jj = 1; jj<cntr; jj++) getline(listFramesFile,frameName); // to bypass for TRE
  

string res;


if (cntr==1) res= "output_new/" + item +"_OPE_ours.txt"; else res = "output_new/"+item+"_TRE_ours_"+to_string(cntr)+".txt";
	// Write Results
	//ofstream resultsFile;
	//string resultsPath = res;
	//resultsFile.open(resultsPath);

	// Frame counter
	int nFrames=0;
Mat imageBW;
cv::Rect result_old;
// for iter
double min, max;
Mat hist;
int histsize = 256, num_pix, thresh;
float srange[] = {0,256};
const float* histRange = { srange };
float mean1_old, mean1 , mean2_old, mean2, m1, m2;
//----
 cout << "--- Dataset selected --- >>> "<<item<<endl;
	while ( getline(listFramesFile, frameName) ){
	//  for (nFrames=0; nFrames<=frameName.size(); ++nFrames){
			frameName = folder_add+"/"+frameName;
				
        
   		// Read each frame from the list
		frame = imread(frameName, CV_LOAD_IMAGE_COLOR);
		if(!frame.data)
            cerr << "Problem loading image!!!" << endl;
       //cout <<"Nframes: "<<frameName[nFrames]<<endl;
	   // modified - Sushil Bharati
	   	bool use_lab = false;
        bool remove_border =false;
	    bool use_geodesic = false; // this is old style and would not perform better when blurred image
	
	begin = clock(); // tic
	
		
		//cout << nFrames <<endl;
		if (nFrames == 0) {
			//auto detection
			 Mat imageBW;
			 Mat salimg = doWork(frame,use_lab,remove_border,use_geodesic);
			
			 
			 // OTSU's threshold -- used in ICTAI 2016
			  salimg.convertTo(salimg, CV_8UC1);
			 Mat dst;
			 cv::GaussianBlur(salimg,dst,Size(5,5),0,0);		
	         cv::threshold(dst, imageBW, 0, 255, CV_THRESH_BINARY | CV_THRESH_OTSU);
			
			
			/*
			//Iterative threshold method -- Modified for IEEE Journal 		 
			// iterative threshold method - Sushil - modified for IEEE journal
			
            cv::minMaxLoc(salimg, &min, &max);
			salimg.convertTo(salimg, CV_8UC1,255.0/(max-min));
			 			
			 // get the histogram
			 calcHist(&salimg,1,0,Mat(),hist,1,&histsize,&histRange,true,false);
			 
			 //mean intensity of the image
			 cv::Scalar mean_int = cv::mean(salimg);
			thresh = round(mean_int(0));
			 
			 //applying the algorithm
			 mean1_old = 0;
			 mean2_old = 0;
			 while (true)
			 {
				 m1=0, m2=0;num_pix = 0;
				 for (int i=1; i<=thresh; i++)
				 {
					 m1 = m1 + i*hist.at<float>(i-1);
					 num_pix = num_pix + hist.at<float>(i-1);
				 }
				 mean1 = m1/num_pix; // mean intensity of region 1
				 num_pix = 0;
				 for (int i=thresh+1;i<=histsize;i++)
				 {
					 m2 = m2 + i*hist.at<float>(i-1);
					 num_pix = num_pix + hist.at<float>(i-1);
				 }
				 mean2 = m2/num_pix; //mean intensity of region 2
				 if ((mean1 - mean1_old) < 1 && (mean2 - mean2_old)< 1) break; 
				 mean1_old = mean1; mean2_old = mean2;
				 thresh = round((mean1 + mean2)/2);
				 
			 }
	         cv::threshold(salimg,imageBW,thresh,1,CV_THRESH_BINARY);
			
				*/
			
			//- --------------------------------		 
			// imshow ("First Frame",imageBW);
			 //auto localization
			 Mat Points;
            findNonZero(imageBW,Points);
            Rect First_Rect=boundingRect(Points);
			// / width = First_Rect.width; height = First_Rect.height;
			tracker.init(First_Rect, frame);
	     	rectangle(frame, First_Rect, Scalar(0,0,255), 2, 8 );
		//	resultsFile << First_Rect.x << "," << First_Rect.y<< "," << First_Rect.width << "," << First_Rect.height<< endl;
		} 
		
		else{
			
			result = tracker.update(frame);
			
			// -1 -- is less than or equal to 0.5
			// -5-- is less than or equal to 0.3
			// -10-- is less than or equal to 0.2
			if (result.x == -1 && result.x == -1 || 
			result.x == -5 && result.x == -5 || result.x == -10 && result.x == -10) 
			{
				width = result_old.width;
				height = result_old.height;
				int wd, hd;
				
			//-$	cout << "peak surge detected in "<<nFrames<<" code: " <<result.x<<endl;
				
				// Adaptive search region
				if (result.x == -1)
				{
				//	cout << "peak value surged in "<<-1<<endl;
					wd = ceil (1.75*result_old.width);
			        hd = ceil (1.75*result_old.height);			        				
				}
				else if (result.x == -5)
				{
				//	cout << "peak value surged in "<<-5<<endl;
					wd = ceil (2*result_old.width);
			        hd = ceil (2*result_old.height);	
				}
				else if (result.x == -10)
				{
				//	cout << "peak value surged in "<<-10<<endl;
					wd = frame.rows;
					hd = frame.cols;
				}
			
			if (result_old.x - wd < 0)  xMin = 0; else xMin = result_old.x - wd;
			 if (result_old.y - hd < 0) yMin = 0; else yMin = result_old.y - hd;
			 float width1,height1;
			 width1 = ((xMin + width + 2*wd) > frame.cols) ? (frame.cols - xMin)-1: width + 2*wd;
			 height1 = ((yMin + height + 2*hd) > frame.rows) ? (frame.rows - yMin)-1 : height + 2*hd;
			 if (xMin==0 && yMin==0) {width1 = frame.cols; height1 = frame.rows;}
		//	  if (xMin + result.width + (wd*2) > frame.cols && xMin!=0) w = (frame.cols - xMin)-1; else w = result.width + (wd*2);
		//	    if (yMin + result.width + (hd*2) > frame.rows && yMin!=0) h = (frame.rows - yMin)-1; else h = result.width + (hd*2);
			//  cout << "new area: " << xMin << " "<< yMin << " "<< w << " "<<h;
            cv::Rect myROI(xMin, yMin, width1, height1);
			    
			 // Crop the full image to required image contained by the rectangle myROI
			  cv::Mat croppedImage = frame(myROI);
			  
			// imshow ("Region",croppedImage);
			
			
				Mat imageBW;
			 Mat salimg = doWork(croppedImage,use_lab,remove_border,use_geodesic);
			// string s= "./out_imgs/" +item +"_" + to_string(nFrames) + "_salimg.png";
			// cout << nFrames << endl;
			
			
			// imshow("sal",salimg);
			
		 
			
			 // thresholding using OTSU - used in ICTAI 2016 by Sushil Bharati
			 salimg.convertTo(salimg, CV_8UC1);
			  Mat dst;
			 cv::GaussianBlur(salimg,dst,Size(5,5),0,0); //blurring before threshold supress noise
	         cv::threshold(dst, imageBW, 0, 255, CV_THRESH_BINARY | CV_THRESH_OTSU); 
			 /*
			 
			// iterative threshold method - Sushil - modified for IEEE journal
		
            cv::minMaxLoc(salimg, &min, &max);
			salimg.convertTo(salimg, CV_8UC1,255.0/(max-min));
						
			 // get the histogram
			 calcHist(&salimg,1,0,Mat(),hist,1,&histsize,&histRange,true,false);
			 
			 //mean intensity of the image
			 cv::Scalar mean_int = cv::mean(salimg);
			thresh = round(mean_int(0));
			 
			 //applying the algorithm
			mean1_old = 0;
			mean2_old =0;
		    
			 while (true)
			 {
				  m1=0, m2=0;num_pix = 0;
				 for (int i=1; i<=thresh; i++)
				 {
					 m1 = m1 + i*hist.at<float>(i-1);
					 num_pix = num_pix + hist.at<float>(i-1);
				 }
				 mean1 = m1/num_pix; // mean intensity of region 1
				 num_pix = 0;
				 for (int i=thresh+1;i<=histsize;i++)
				 {
					 m2 = m2 + i*hist.at<float>(i-1);
					 num_pix = num_pix + hist.at<float>(i-1);
				 }
				 mean2 = m2/num_pix; //mean intensity of region 2
				 num_pix = 0;
				 if ((mean1 - mean1_old) < 1   && (mean2 - mean2_old)< 1) break; 
				 mean1_old = mean1; mean2_old = mean2;
				 thresh = round((mean1 + mean2)/2);
				 
			 } 
			 // applying the threshold obtained using iterative algorithm
	         cv::threshold(salimg,imageBW,thresh,1,CV_THRESH_BINARY);
			 
			 */
			 
		    	//cout<<"Threshold-->"<<thresh<<endl;	 
			 
			// for (int i=1; i<=histsize; i++)
			 //   if (hist.at<float>(i-1)!=0)
			  //     cout << i-1 <<" -->  " <<hist.at<float>(i-1)<<endl;
			  			
				//cout<<hist;
			 
	       
			//  imshow ("Threshold",imageBW); 
			
			
			//s = "./out_imgs/" +item +"/" + to_string(nFrames) + "_thresh.png";
			 //imwrite (s,imageBW);
			 			 
			 
			 //auto localization
			 Mat Points;
            findNonZero(imageBW,Points);
            result=boundingRect(Points);
			int a,b,c,d;
			//adjusting the co-ordinates for the original frame
			  a = xMin + result.x; 
              b = yMin + result.y;
			  //check for height and width
	 		if (result.width < 0.5*result_old.width && result.height < 0.5*result_old.height || 
			 result.width >= 2*result_old.width && result.height >= 2*result_old.height)
		{
			  //-$ cout <<"default taken...in frame #"<<nFrames<<endl;
	 a = result_old.x+1;
	 b = result_old.y+1;
	 c = result_old.width;            
		 d = result_old.height;
		}
		 else 
	   {
		   
		   c =result.width;
		   d = result.height;
	   }
	   result = Rect(a,b,c,d);
	   tracker.init(result, frame);
			}
		  rectangle(frame, Point( result.x, result.y ), Point( result.x+result.width, result.y+result.height), Scalar( 0, 255, 255 ), 2, 8 );
     	//	resultsFile << result.x << "," << result.y << "," << result.width << "," << result.height << endl;
		result_old = result;
		}
end = clock(); //toc
t = t + end-begin;

		nFrames++;

		if (!SILENT){
			//string s = to_string(nFrames);
			imshow("tracker_result_ICTAI",frame);
			verbose = false;
		waitKey(1);
		
		}
		}
	

if (verbose){
cout <<" Total Frames processed = "<<nFrames<<endl;
	cout << " Average speed for MBD + KCF tracking is "<<nFrames/(t/double(CLOCKS_PER_SEC)) << " fps"<<endl;
	
}

sum_time = sum_time + nFrames/(t/double(CLOCKS_PER_SEC));
t=0;
	
//	resultsFile.close();

	listFile.close();
	fflush(stdin);

//}

	}
	// enable this only when not displaying frames on screen
		cout << "Average speed for 25 datasets: "<< sum_time / 2.0<<endl ; 
}

